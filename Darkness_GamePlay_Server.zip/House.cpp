#include "stdafx.h"
#include "House.h"



House::House()
{
}


House::~House()
{
}
