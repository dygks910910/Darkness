#pragma once
class Map
{
private:
	XMFLOAT4X4 worldMatrix;
	

public:
	Map();
	~Map();
};

