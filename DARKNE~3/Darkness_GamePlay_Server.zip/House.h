#pragma once
#include "Obstacle.h"
class House :
	public Obstacle
{
public:
	House();
	virtual ~House();
};

