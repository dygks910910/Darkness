#include "stdafx.h"
#include "Server.h"

int main()
{
	Server server;

	server.Progress();

	return 0;
}